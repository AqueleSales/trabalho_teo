# 🦋 Paliar para Cuidar - Website S-Tier

Um website profissional e moderno dedicado à educação sobre cuidados paliativos, câncer e qualidade de vida.

## ✨ O Que Foi Renovado

### Design & Estilo
- ✅ **Design Premium**: Interface moderna, minimalista e profissional
- ✅ **Paleta de Cores Refinada**: Teal (verde-azulado), roxo, amarelo e cinzas sofisticados
- ✅ **Tipografia Elegante**: Hierarquia visual clara e legibilidade otimizada
- ✅ **Componentes Bonitos**: Cards com sombras refinadas, botões com gradientes, micro-interações

### Animações & Interatividade
- ✅ **Animações Suaves**: Fade-ins, slides, floats e transforms elegantes
- ✅ **Parallax Effect**: Movimento de fundo ao scrollar
- ✅ **Flip Cards**: Cartões que viram para revelar respostas (Mitos & Verdades)
- ✅ **Scroll Reveal**: Elementos aparecem conforme você rola a página
- ✅ **Hover States**: Botões e cards com transições delicadas

### UX/UI Melhorado
- ✅ **Responsivo Perfeito**: Mobile-first, funciona em todos os tamanhos
- ✅ **Acessibilidade**: VLibras integrado, bom contraste, navegação clara
- ✅ **Smooth Scrolling**: Navegação fluida entre seções
- ✅ **Text-to-Speech**: Botão para ouvir conteúdo da página
- ✅ **Mural Interativo**: Relatos de usuários com localStorage

### Estrutura de Páginas
1. **Home** - Hero section inspirador + jornada do cuidado + CTA cards
2. **Entendendo o Câncer** - Sintomas, diagnósticos, tratamentos, prevenção, flip cards
3. **Cuidados & Acolhimento** - PICS, suporte familiar, mensagem de voz
4. **Direitos & Apoio** - Direitos legais, hospitais SUS, ONGs, informações práticas
5. **Vivências** - Storytelling, mural interativo para compartilhar histórias
6. **Sobre** - Missão, visão, equipe, referências bibliográficas

## 📋 Estrutura de Arquivos

```
seu-projeto/
├── app.py                      # Backend Flask
├── templates/
│   ├── base.html              # Template base com header/footer
│   ├── index.html             # Home
│   ├── entendendo-cancer.html
│   ├── cuidado-acolhimento.html
│   ├── direitos-rede.html
│   ├── vivencias.html
│   └── sobre.html
└── static/
    └── css/
        └── style.css          # Estilos premium
```

## 🚀 Como Instalar & Rodar

### Pré-requisitos
- Python 3.8+
- Flask

### Instalação

1. **Clone ou extraia os arquivos**
```bash
cd seu-projeto
```

2. **Instale Flask**
```bash
pip install flask
```

3. **Crie a estrutura de pastas**
```bash
mkdir -p templates static/css
```

4. **Coloque os arquivos nos diretórios corretos**
```
app.py → na raiz
*.html → em templates/
style.css → em static/css/
```

5. **Execute a aplicação**
```bash
python app.py
```

6. **Abra no navegador**
```
http://localhost:5000
```

## 🎨 Características Premium

### Design System
- **Cores**: Teal primário (#0f766e), Roxo (#6366f1), Amarelo (#f59e0b)
- **Espaçamento**: Sistema de variáveis CSS para consistência
- **Shadows**: 5 níveis de sombra (sm a 2xl)
- **Transitions**: Durações padronizadas (fast, normal, slow)

### Animações
- Slide Down (Header)
- Fade In Up (Seções)
- Float (Background)
- Shimmer (Imagens)
- Flip Card (Interativo)
- Slide In Left (Comentários)

### Componentes Reutilizáveis
- `.btn` - Botões versáteis
- `.card` - Cards informativos
- `.feature-row` - Layout zigue-zague
- `.section-accent` - Seções coloridas
- `.list-refined` - Listas estilizadas
- `.journey-container` - Timeline de etapas

## 📱 Responsividade

- **Desktop**: Layout completo com 2+ colunas
- **Tablet** (768px): Ajustes de grid e espaçamento
- **Mobile** (480px): Single column, navegação otimizada

## ♿ Acessibilidade

- VLibras integrado para Libras
- Bom contraste de cores (WCAG AA)
- Navegação por teclado
- Text-to-speech funcional
- Semântica HTML5 apropriada

## 🔊 Funcionalidades Especiais

### Botão "Ouvir Página"
```javascript
// Sintetiza fala em português com velocidade controlada
utterance.lang = 'pt-BR';
utterance.rate = 0.9;
```

### Mural de Vivências
```javascript
// Usa localStorage para persistência local
localStorage.getItem('mural_relatos')
localStorage.setItem('mural_relatos', JSON.stringify(salvos))
```

### Flip Cards (Mitos & Verdades)
```javascript
// Fetch dinâmico de /api/mitos-verdades
// Animação CSS 3D com perspective
```

## 🔧 Personalizações

### Alterar Cores
Edite as variáveis no topo de `style.css`:
```css
:root {
  --primary: #0f766e;
  --secondary: #6366f1;
  --accent: #f59e0b;
}
```

### Adicionar Novas Seções
Use as classes existentes:
```html
<section class="reveal">
  <h2>Meu Título</h2>
  <div class="cards-grid">
    <div class="card">...</div>
  </div>
</section>
```

### Modificar Animações
Edite ou crie novas @keyframes em `style.css`

## 📊 Performance

- **CSS**: Minificado em produção
- **JavaScript**: Vanilla JS, sem dependências externas
- **Imagens**: Usando emojis para ícones (zero requisições)
- **Fonts**: System fonts (Apple, Segoe, Roboto)
- **Carregamento**: Lazy loading com Intersection Observer

## 🌐 Deploy

### Heroku
```bash
pip freeze > requirements.txt
# Adicionar Procfile
web: gunicorn app:app
# Deploy
git push heroku main
```

### PythonAnywhere
1. Upload files
2. Configure Flask app
3. Enable web app
4. Visit seu-site.pythonanywhere.com

### Vercel/Netlify (Frontend apenas)
Exportar HTML estático e hospedar como site estático

## 🐛 Troubleshooting

### "Module 'flask' not found"
```bash
pip install flask
```

### Templates não carregam
Verifique que estrutura de pastas está correta:
```
app.py
templates/ (com todos os .html)
static/css/ (com style.css)
```

### Estilos não aparecem
Reinicie o servidor com `CTRL+C` e execute `python app.py` novamente

### Text-to-speech não funciona
- Firefox e Chrome funcionam natively
- Safari: verificar configurações de privacidade
- Mobile: pode precisar de ação do usuário primeiro

## 📚 Recursos Usados

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Python Flask
- **Acessibilidade**: VLibras
- **Tipografia**: System fonts
- **Ícones**: Unicode/Emojis

## 📝 Licença

Projeto acadêmico - Universidade de Brasília (UnB)
Desenvolvido com propósito educacional e humanitário

## 💚 Contribuições

Sinta-se à vontade para melhorar este projeto!
- Reporte bugs
- Sugira novas funcionalidades
- Contribua com conteúdo

---

**Desenvolvido com ❤️ para educar e acolher** 🦋

Qualquer dúvida ou sugestão, entre em contato com o Departamento de Enfermagem da UnB.
